import FavoritesList from "@/1-pages/favorites-list/ui/FavoritesList";

export default FavoritesList;
