import CollectionsList from "@/1-pages/collections/collections-list/ui/CollectionsList";

export default CollectionsList;
