import CollectionDetailScreen from "@/1-pages/collections/collection-detail/ui/CollectionDetail";
export default CollectionDetailScreen;
