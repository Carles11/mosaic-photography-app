import CommentsList from "@/1-pages/comments-list/ui/CommentsList";

export default CommentsList;
