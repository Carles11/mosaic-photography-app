import { ForgotPasswordScreen } from "@/1-pages/auth/forgot-password/ui/ForgotPasswordScreen";

export default ForgotPasswordScreen;
