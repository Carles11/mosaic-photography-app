import { PasswordResetScreen } from "@/1-pages/auth/password-reset/ui/PasswordResetScreen";

export default PasswordResetScreen;
