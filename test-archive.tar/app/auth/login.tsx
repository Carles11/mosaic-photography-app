import { LoginScreen } from "@/1-pages/auth/login/ui/LoginScreen";

export default LoginScreen;
