import { ConfirmEmailChangeScreen } from "@/1-pages/auth/confirm-email-change/ui/ConfirmEmailChangeScreen";

export default ConfirmEmailChangeScreen;
