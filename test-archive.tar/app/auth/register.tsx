import { RegisterScreen } from "@/1-pages/auth/register/ui/RegisterScreen";

export default RegisterScreen;
