import { VerifyEmailScreen } from "@/1-pages/auth/verify-email/ui/VerifyEmailScreen";

export default VerifyEmailScreen;
