import { MagicLinkScreen } from "@/1-pages/auth/magic-link/ui/MagicLinkScreen";

export default MagicLinkScreen;
