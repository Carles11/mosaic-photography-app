import PhotographerDetailScreen from "@/1-pages/photographers/ui/PhotographerDetailScreen";

export default PhotographerDetailScreen;
