export const fonts = {
  regular: "TradeGothic-Regular",
  bold: "TradeGothic-Bold",
  // add other weights as needed
};